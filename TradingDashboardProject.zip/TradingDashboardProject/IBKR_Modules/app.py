import pandas as pd
import datetime as dt
from dash import Dash
from threading import Timer
import webbrowser

from data.fetch_data import connect_ib, disconnect_ib
from backtest.engine import run_backtest
from metrics.performance import calculate_metrics
from dashboard.calendar import build_calendar_component
from dashboard.layout import build_layout
from strategies import strategy_registry

# === Prompt User for Inputs ===
print("Available strategies:", ", ".join(strategy_registry.keys()))
strategy_name = input("Enter strategy name: ").strip().lower()
if strategy_name not in strategy_registry:
    print(f"Invalid strategy '{strategy_name}'. Exiting.")
    exit()

symbol = input("Enter symbol to backtest (e.g., SPY): ").strip().upper()

try:
    start_input = input("Enter start date (YYYY-MM-DD): ")
    START_DATE = dt.datetime.strptime(start_input, "%Y-%m-%d").date()

    end_input = input("Enter end date (YYYY-MM-DD): ")
    END_DATE = dt.datetime.strptime(end_input, "%Y-%m-%d").date()
except ValueError:
    print("Invalid date format. Please use YYYY-MM-DD.")
    exit()

# === Connect to IBKR ===
ib = connect_ib()

# === Run Backtest ===
strategy_fn = strategy_registry[strategy_name]
df_results, executions, time_buckets, symbol_pnl = run_backtest(
    ib, strategy_fn, symbol, START_DATE, END_DATE
)

if df_results.empty:
    print("No trades were taken. Check your entry/exit logic or data availability.")
    disconnect_ib(ib)
    exit()

# === Metrics & Calendar ===
summary_data, perf_by_time, perf_by_symbol, perf_by_weekday, daily_pnl = calculate_metrics(
    df_results, time_buckets, symbol_pnl, START_DATE, END_DATE
)

calendar_components = []
current = START_DATE.replace(day=1)
end_month = END_DATE.replace(day=1)
while current <= end_month:
    calendar_components.append(build_calendar_component(daily_pnl, current.year, current.month))
    current = (current.replace(day=28) + pd.Timedelta(days=4)).replace(day=1)

# === Build & Launch Dash App ===
app = Dash(__name__)
app.layout = build_layout(
    df_results,
    executions,
    summary_data,
    perf_by_time,
    perf_by_symbol,
    perf_by_weekday,
    calendar_components
)

Timer(1, lambda: webbrowser.open("http://127.0.0.1:8050")).start()
app.run()

disconnect_ib(ib)
