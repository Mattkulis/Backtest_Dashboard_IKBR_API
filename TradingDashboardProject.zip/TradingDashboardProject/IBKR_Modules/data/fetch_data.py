from ib_insync import IB, Stock, util
import pandas as pd

def connect_ib():
    ib = IB()
    ib.connect('127.0.0.1', 7497, clientId=1)
    return ib

def disconnect_ib(ib):
    ib.disconnect()

def get_1min_data(ib, symbol, date):
    contract = Stock(symbol, 'SMART', 'USD')
    formatted_date = date.strftime('%Y%m%d 16:00:00')
    bars = ib.reqHistoricalData(
        contract,
        endDateTime=formatted_date,
        durationStr='1 D',
        barSizeSetting='1 min',
        whatToShow='TRADES',
        useRTH=True,
        formatDate=1
    )
    df = util.df(bars)
    if df is None or df.empty:
        return None
    df['datetime'] = pd.to_datetime(df['date'])
    df.set_index('datetime', inplace=True)
    df.drop(columns=['date'], inplace=True)
    return df
