import datetime as dt
import pandas as pd

START_DATE = dt.date(2022, 1, 1)
END_DATE = dt.date(2025, 7, 1)
TRADING_DAYS = pd.bdate_range(start=START_DATE, end=END_DATE).to_list()
