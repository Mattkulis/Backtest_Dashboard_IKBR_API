import numpy as np

def calculate_metrics(df_results, time_buckets, symbol_pnl, start_date, end_date):
    df_results = df_results.sort_values(by='exit_time')
    df_results['cum_pnl'] = df_results['pnl'].cumsum()

    avg_return = df_results['pnl'].mean()
    downside_std = df_results[df_results['pnl'] < 0]['pnl'].std()
    sortino = avg_return / downside_std * np.sqrt(252) if downside_std != 0 else 0
    win_rate = (df_results['pnl'] > 0).mean()
    ev = avg_return
    cum_return = df_results['cum_pnl'].iloc[-1]
    drawdown = df_results['cum_pnl'].cummax() - df_results['cum_pnl']
    max_drawdown = drawdown.max()
    calmar = cum_return / max_drawdown if max_drawdown != 0 else 0

    avg_hold_seconds = df_results['hold_time'].mean().total_seconds()
    days, rem = divmod(avg_hold_seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, seconds = divmod(rem, 60)
    avg_hold_fmt = f"{int(days):02d}:{int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}"

    summary_data = {
        "Start Date:": start_date.strftime('%Y-%m-%d'),
        "End Date:": end_date.strftime('%Y-%m-%d'),
        "Total Trades:": len(df_results),
        "Avg Hold Time:": avg_hold_fmt,
        "Win Rate:": f"{win_rate:.2%}",
        "Calmar Ratio:": f"{calmar:.2f}",
        "Sortino Ratio:": f"{sortino:.2f}",
        "Expected Value Per Trade:": f"{ev:.2f}",
        "Cumulative PnL:": f"{cum_return:+.2f}"
    }

    def sum_hours(hour_list):
        return sum([time_buckets.get(h, 0) for h in hour_list])

    perf_by_time = {
        "Open (9:30–11:30)": f"{sum_hours(['09', '10', '11']):+.2f}",
        "Noon (11:31–14:00)": f"{sum_hours(['12', '13']):+.2f}",
        "EOD (14:01–16:00)": f"{sum_hours(['14', '15']):+.2f}"
    }

    perf_by_symbol = [
        ["Ticker", "Symbol", "Cumulative P&L"],
        *[[ticker, ticker, f"{pnl:+.2f}"] for ticker, pnl in symbol_pnl.items()]
    ]

    df_results['exit_date'] = df_results['exit_time'].dt.date
    df_results['exit_weekday'] = df_results['exit_time'].dt.day_name()
    weekday_pnl = df_results.groupby('exit_weekday')['pnl'].sum()
    weekday_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    perf_by_weekday = {day: f"{weekday_pnl.get(day, 0):+.2f}" for day in weekday_order}

    daily_pnl = df_results.groupby('exit_date')['pnl'].sum().to_dict()

    return summary_data, perf_by_time, perf_by_symbol, perf_by_weekday, daily_pnl
