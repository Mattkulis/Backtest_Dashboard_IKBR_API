import datetime as dt
import calendar
from dash import html

def build_calendar_component(daily_pnl_map, year, month):
    first_wd, days_in_month = calendar.monthrange(year, month)
    month_start = dt.date(year, month, 1)
    lead_start = month_start - dt.timedelta(days=first_wd) if first_wd > 0 else month_start
    month_end = dt.date(year, month, days_in_month)

    cells = []
    for i in range(42):
        day = lead_start + dt.timedelta(days=i)
        cells.append(day)
        if day >= month_end and day.weekday() == 6:
            break

    weekday_labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    header_row = [html.Div(lbl, style={
        'textAlign': 'center',
        'fontWeight': 'bold',
        'padding': '4px',
        'borderBottom': '1px solid #ccc'
    }) for lbl in weekday_labels]

    day_cells = []
    for day in cells:
        in_month = (day.month == month)
        is_weekend = day.weekday() >= 5
        pnl = daily_pnl_map.get(day, None) if in_month else None

        if not in_month or is_weekend or pnl is None:
            bg = '#dcdcdc'
            pnl_str = ''
        else:
            bg = '#b6e8b6' if pnl > 0 else '#f5b5b5' if pnl < 0 else '#dcdcdc'
            pnl_str = f"{pnl:+.2f}"

        day_label = f"{day.day:02d}"
        cell = html.Div([
            html.Div(day_label, style={'fontSize': '10px', 'marginBottom': '2px'}),
            html.Div(pnl_str, style={'fontSize': '12px', 'fontWeight': 'bold'})
        ], style={
            'height': '50px',
            'width': '100px',
            'display': 'flex',
            'flexDirection': 'column',
            'justifyContent': 'center',
            'alignItems': 'center',
            'border': '1px solid #ccc',
            'backgroundColor': bg,
            'margin': '1px'
        })
        day_cells.append(cell)

    grid_children = header_row + day_cells
    calendar_grid = html.Div(
        grid_children,
        style={
            'display': 'grid',
            'gridTemplateColumns': 'repeat(7, 100px)',
            'gridAutoRows': 'minmax(50px, auto)',
            'gap': '0px',
            'width': '100%',
            'maxWidth': '700px',
            'margin': '0 auto'
        }
    )

    month_name = calendar.month_name[month]
    month_header = html.Div(
        f"{month_name} {year}",
        style={'textAlign': 'center', 'fontWeight': 'bold', 'marginBottom': '8px', 'fontSize': '16px'}
    )

    return html.Div([month_header, calendar_grid], style={'padding': '10px'})
