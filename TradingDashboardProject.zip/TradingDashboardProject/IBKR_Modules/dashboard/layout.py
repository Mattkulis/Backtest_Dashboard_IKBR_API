from dash import dcc, html
import plotly.graph_objs as go

def build_layout(df_results, executions, summary_data, perf_by_time, perf_by_symbol, perf_by_weekday, calendar_components):
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df_results['exit_time'],
        y=df_results['cum_pnl'],
        mode='lines+markers',
        name='Equity Curve',
        line=dict(color='green')
    ))

    fig.update_layout(
        title={'text': 'Equity Curve (PnL) for Strategy: Opening Range Breakdown (ORBD)',
               'font': {'size': 20, 'family': 'Arial Black', 'color': 'black'},
               'x': 0.5, 'xanchor': 'center'},
        xaxis_title='Time (EST)',
        yaxis_title='Cumulative PnL',
        hovermode='x unified',
        xaxis_rangeslider_visible=True
    )

    return html.Div(style={'display': 'flex', 'flexDirection': 'row', 'height': '100vh'}, children=[
        html.Div(children=[
            dcc.Graph(id='equity-curve', figure=fig, style={'height': '70vh'}),

            html.Details([
                html.Summary("📅 Calendar", style={'fontWeight': 'bold', 'fontSize': '18px'}),
                html.Div(calendar_components, style={
                    'resize': 'vertical',
                    'overflow': 'auto',
                    'minHeight': '100px',
                    'maxHeight': '600px',
                    'border': '1px solid #ccc',
                    'padding': '5px'
                })
            ], style={'marginTop': '20px', 'padding': '10px', 'backgroundColor': '#f1f1f1'}),

            html.Details([
                html.Summary("📄 Executions", style={'fontWeight': 'bold', 'fontSize': '18px'}),
                html.Div([
                    html.Table([
                        html.Thead([
                            html.Tr([html.Th(h, style={'fontWeight': 'bold'}) for h in ["Type", "Time", "Price", "Quantity", "P&L"]])
                        ]),
                        html.Tbody([
                            html.Tr([html.Td(cell) for cell in row]) for row in executions
                        ])
                    ])
                ], style={'overflowX': 'auto', 'padding': '10px'})
            ], style={'marginTop': '20px', 'padding': '10px', 'backgroundColor': '#f1f1f1'})
        ], style={'flex': '1', 'overflowY': 'auto', 'padding': '10px', 'height': '100vh'}),

        html.Div(children=[
            html.Details([
                html.Summary("Strategy Results Overview", style={'fontWeight': 'bold', 'fontSize': '18px'}),
                html.Table([
                    html.Tbody([
                        html.Tr([html.Td(k, style={'fontWeight': 'bold'}), html.Td(v)]) for k, v in summary_data.items()
                    ])
                ])
            ]),
            html.Details([
                html.Summary("📆 Performance by Day of Week", style={'fontWeight': 'bold', 'fontSize': '18px'}),
                html.Table([
                    html.Tbody([
                        html.Tr([html.Td(day, style={'fontWeight': 'bold'}), html.Td(pnl)]) for day, pnl in perf_by_weekday.items()
                    ])
                ])
            ]),
            html.Details([
                html.Summary("Performance by Time of Day", style={'fontWeight': 'bold', 'fontSize': '18px'}),
                html.Table([
                    html.Tbody([
                        html.Tr([html.Td(k, style={'fontWeight': 'bold'}), html.Td(v)]) for k, v in perf_by_time.items()
                    ])
                ])
            ]),
            html.Details([
                html.Summary("📈 Performance by Symbol", style={'fontWeight': 'bold', 'fontSize': '18px'}),
                html.Table([
                    html.Thead([
                        html.Tr([html.Th(col, style={'fontWeight': 'bold'}) for col in perf_by_symbol[0]])
                    ]),
                    html.Tbody([
                        html.Tr([html.Td(cell) for cell in row]) for row in perf_by_symbol[1:]
                    ])
                ])
            ])
        ], style={
            'width': '20vw',
            'padding': '10px',
            'borderLeft': '1px solid #ccc',
            'backgroundColor': '#f9f9f9',
            'overflow': 'auto'
        })
    ])
