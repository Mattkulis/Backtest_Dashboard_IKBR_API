def calculate_vwap(df):
    vwap_numerator = (df['close'] * df['volume']).cumsum()
    vwap_denominator = df['volume'].cumsum()
    df['vwap'] = vwap_numerator / vwap_denominator
    return df
