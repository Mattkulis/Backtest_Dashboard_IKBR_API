import pandas as pd
from data.fetch_data import get_1min_data

def run_backtest(ib, strategy_fn, symbol, start_date, end_date):
    trading_days = pd.bdate_range(start=start_date, end=end_date).to_list()

    results = []
    executions = []
    time_buckets = {}
    symbol_pnl = {}

    for date in trading_days:
        try:
            print(f"Processing data for {date.strftime('%B %Y')}")
            df = get_1min_data(ib, symbol, date)
            if df.empty:
                continue

            trades_df = strategy_fn(df, date)
            if trades_df.empty:
                continue

            entry_idx = None
            entry_price = None
            entry_time = None

            for i, row in trades_df.iterrows():
                if row.get('entry'):
                    entry_idx = i
                    entry_price = row['close']
                    entry_time = i

                if row.get('exit') and entry_idx is not None:
                    exit_price = row['close']
                    exit_time = i
                    pnl = (entry_price - exit_price) * 100  # Short 100 shares
                    hold_time = exit_time - entry_time

                    results.append({
                        'entry_time': entry_time,
                        'exit_time': exit_time,
                        'entry_price': entry_price,
                        'exit_price': exit_price,
                        'pnl': pnl,
                        'hold_time': hold_time
                    })

                    executions.append([
                        "Entry", entry_time.strftime('%Y-%m-%d %H:%M'),
                        f"{entry_price:.2f}", "100 shares", ""
                    ])
                    executions.append([
                        "Exit", exit_time.strftime('%Y-%m-%d %H:%M'),
                        f"{exit_price:.2f}", "100 shares", f"{pnl:+.2f}"
                    ])

                    hour = entry_time.strftime("%H")
                    time_buckets[hour] = time_buckets.get(hour, 0) + pnl
                    symbol_pnl[symbol] = symbol_pnl.get(symbol, 0) + pnl

                    entry_idx = None  # Reset after trade completion

        except Exception as e:
            print(f"Error on {date}: {e}")
            continue

    df_results = pd.DataFrame(results)
    if not df_results.empty:
        df_results.sort_values(by="exit_time", inplace=True)
        df_results["cum_pnl"] = df_results["pnl"].cumsum()
        df_results["return"] = df_results["pnl"] / 100  # assuming 100 shares

    return df_results, executions, time_buckets, symbol_pnl
