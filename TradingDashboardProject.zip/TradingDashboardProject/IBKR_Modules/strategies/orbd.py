import pandas as pd
import datetime as dt

def detect_entries_exits(df, date):
    df = df.copy()
    df['ema'] = df['close'].ewm(span=9, adjust=False).mean()
    df['entry'] = False
    df['exit'] = False

    range_minutes = 6
    i = range_minutes
    cutoff_time_reached = False

    while i < len(df) - 10 and not cutoff_time_reached:
        range_df = df.iloc[i - range_minutes:i]
        range_high = range_df['close'].max()
        range_low = range_df['open'].min()
        range_width = range_high - range_low
        range_max_high = range_df['high'].max()
        range_min_low = range_df['low'].min()

        trigger_candle = df.iloc[i]
        if trigger_candle['close'] < range_low - 0.25 * range_width:
            body = abs(trigger_candle['close'] - trigger_candle['open'])
            if body > 1.3 * (range_max_high - range_min_low):
                i += 1
                continue

            next_candle = df.iloc[i + 1]
            entry_time = next_candle.name

            if entry_time.time() > dt.time(10, 0):
                cutoff_time_reached = True
                break

            if next_candle['low'] < trigger_candle['low']:
                stop_loss = range_max_high
                stop_moved = False
                j = i + 2
                closes_above_ema = 0

                df.loc[entry_time, 'entry'] = True
                entry_price = next_candle['close']

                while j < len(df):
                    bar = df.iloc[j]
                    bar_time = bar.name
                    minutes_since_entry = (bar_time - entry_time).total_seconds() / 60

                    if not stop_moved and minutes_since_entry >= 3:
                        stop_loss = trigger_candle['open']
                        stop_moved = True

                    if bar['high'] >= stop_loss:
                        df.loc[bar_time, 'exit'] = True
                        break

                    if (bar['close'] - bar['ema']) > 0.3 * range_width:
                        df.loc[bar_time, 'exit'] = True
                        break

                    if bar['close'] > bar['ema']:
                        closes_above_ema += 1
                    else:
                        closes_above_ema = 0

                    if closes_above_ema >= 3:
                        df.loc[bar_time, 'exit'] = True
                        break

                    j += 1
                i = j
                continue
        i += 1

    return df
