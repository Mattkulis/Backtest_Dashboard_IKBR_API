from strategies.orbd import detect_entries_exits

strategy_registry = {
    "orbd": detect_entries_exits,
}
