from strategies.orbd import detect_entries_exits as orbd

strategy_registry = {
    "orbd": orbd,
    # Add more like:
    # "momentum": momentum,
    # "breakout": breakout,
}
